// Core Imports
import { Fragment } from 'react';

// Custom Components
import Hero from 'components/Hero';
import PageProgress from 'components/PageProgress';
import Settings from 'icons/Settings';
import Tiles from 'components/Tiles';
import Facts from 'components/Facts';
import Check from 'icons/Check';
import User from 'icons/User';
import BriefcaseTwo from 'icons/BriefcaseTwo';
import AwardTwo from 'icons/AwardTwo';

/**
 * List of key statistics to display in the "Facts" section.
 * @type {Array<{ id: number, value: number, Icon: React.ComponentType, title: string }>}
 */
const factList = [
  { id: 1, value: 16, Icon: Check, title: 'Years of Experience' },
  { id: 2, value: 219, Icon: User, title: 'Client Worked With' },
  { id: 3, value: 753, Icon: BriefcaseTwo, title: 'Completed Projects' },
  { id: 4, value: 148, Icon: AwardTwo, title: 'Team Members' },
];

/**
 * Home page component for the solar EPC website.
 *
 * @component
 * @returns {JSX.Element}
 */
const Home = () => {
  return (
    <Fragment>
      {/* Page Scroll Indicator */}
      <PageProgress />

      {/* Main Content Area */}
      <main className="content-wrapper overflow-x-hidden">
        <Hero />

        {/* About Section */}
        <section
          className="wrapper bg-light angled lower-end"
          aria-labelledby="solar-epc-heading"
        >
          <div className="container py-14 py-md-12">
            <div className="row gx-lg-8 gx-xl-12 gy-10 align-items-center">
              {/* Left Content */}
              <div className="col-lg-6">
                <Settings
                  className="icon-svg-md mb-4"
                  aria-hidden="true"
                  focusable="false"
                />
                <h1 id="solar-epc-heading" className="display-4 mb-3">
                  Best Solar EPC Company in India – Solario
                </h1>
                <p>
                  Solario is a trusted Solar EPC (Engineering, Procurement, and Construction) company, delivering end-to-end solar energy solutions for residential, commercial, and industrial needs. We specialize in designing, installing, and maintaining high-efficiency solar power systems that reduce electricity bills and promote sustainability.
                </p>
                <p>
                  With years of experience and a team of certified professionals, Solario ensures quality workmanship, seamless project execution, and long-term performance. Whether you're planning a rooftop solar installation, on-grid or off-grid solar plant, we provide customized solar EPC services that maximize your return on investment. Choose Solario for reliable, affordable, and eco-friendly solar energy solutions.
                </p>
              </div>

              {/* Right Visual Component */}
              <div className="col-lg-6 position-relative order-lg-2">
                <Tiles />
              </div>
            </div>
          </div>
        </section>

        {/* Facts Section */}
        <section className="wrapper bg-soft-primary">
          <div className="container py-14 py-md-16">
            <Facts arr={factList} />
          </div>
        </section>
      </main>
    </Fragment>
  );
};

export default Home;
