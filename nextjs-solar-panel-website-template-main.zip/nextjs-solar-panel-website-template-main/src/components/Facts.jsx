import CountUp from 'react-countup';
import PropTypes from 'prop-types';

/**
 * Facts Component
 *
 * Displays animated counters with icons and descriptive titles.
 * Used to highlight key metrics or achievements.
 *
 * @component
 * @param {Object[]} arr - Array of facts to display
 * @param {number} arr[].value - The numeric value to animate
 * @param {string} arr[].title - Description text for the fact
 * @param {React.Component} arr[].Icon - Icon component for the fact
 * @param {string|number} arr[].id - Unique identifier for the fact
 * @returns {JSX.Element}
 */
const Facts = ({ arr }) => {
  return (
    <section
      className="row gy-10 gx-lg-10"
      aria-labelledby="facts-heading"
      role="region"
    >
      <div className="col-12 mx-auto">
        <div
          className="row align-items-center counter-wrapper gy-6 text-center"
          id="facts-heading"
        >
          {arr.map(({ value, title, Icon, id }) => (
            <div
              key={id}
              className="col-md-6 col-lg-3 mb-5 mb-md-0 d-flex flex-column justify-content-center align-items-center"
              aria-label={`Fact: ${value}+ ${title}`}
            >
              <Icon
                className="icon-svg-lg text-primary mb-3"
                role="img"
                aria-hidden="true"
              />
              <div>
                <h3 className="counter" aria-live="polite">
                  <CountUp delay={0.2} duration={3} end={value} suffix="+" />
                </h3>
                <p className="mb-0">{title}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

// PropTypes for runtime type safety
Facts.propTypes = {
  arr: PropTypes.arrayOf(
    PropTypes.shape({
      value: PropTypes.number.isRequired,
      title: PropTypes.string.isRequired,
      Icon: PropTypes.elementType.isRequired,
      id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
    })
  ).isRequired,
};

export default Facts;
