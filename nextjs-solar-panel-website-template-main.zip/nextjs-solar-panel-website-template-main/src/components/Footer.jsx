import Image from 'next/image';
import NextLink from 'components/NextLink';
import SocialLinks from 'components/SocialLinks';
import { services, usefulLinks } from '../data';

/**
 * Renders a list of links under a widget heading.
 *
 * @param {Array} list - Array of link objects (with id, url, title)
 * @param {string} title - Section title
 * @returns {JSX.Element}
 */
const renderWidget = (list, title) => (
  <div className="widget">
    <h3 className="widget-title fs-24 mb-3">{title}</h3>
    <ul className="list-unstyled text-reset mb-0">
      {list.map(({ url, title, id }) => (
        <li key={id}>
          <NextLink href={url} title={title} />
        </li>
      ))}
    </ul>
  </div>
);

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-top secondary-bg overflow-hidden">
      <div className="container pt-10 pt-md-12 pb-2">
        <div className="row gx-10 justify-content-between">

          {/* Brand Info */}
          <div className="col-lg-3">
            <div className="widget d-flex flex-column align-items-start">
              <NextLink
                href="/"
                title="Solario"
                className="text-white display-1 mb-2"
              />
              <p className="lead mb-2 text-justify fs-18 text-white">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque, unde.
              </p>
              <div className="d-flex align-items-start flex-column">
                <h3 className="fs-24 text-white">Follow Us On</h3>
                <SocialLinks className="nav social text-md-end" />
              </div>
            </div>
          </div>

          {/* Useful Links */}
          <div className="col-sm-6 col-md-4 col-lg-3 mt-5 mt-lg-0 d-flex justify-content-md-center text-white">
            {renderWidget(usefulLinks, 'Useful Links')}
          </div>

          {/* Services Links */}
          <div className="col-sm-6 col-md-4 col-lg-2 mt-5 mt-lg-0 d-flex justify-content-md-center text-white">
            {renderWidget(services, 'Services')}
          </div>

          {/* Contact Info */}
          <div className="col-md-4 col-lg-3 mt-5 mt-lg-0 d-flex justify-content-md-center text-white">
            <div className="widget">
              <h3 className="widget-title fs-24 mb-3">Contact Us</h3>

              <div className="d-flex align-items-start mb-2">
                <i className="uil uil-location-pin-alt fs-30 text-white" aria-hidden="true" />
                <address className="ms-2 m-0 mt-1 text-white">
                  123 Tech Park, Ta. Richmond, Dist. Greater London, United Kingdom – SW1A 1AA
                </address>
              </div>

              <div className="d-flex align-items-center mb-2">
                <i className="uil uil-envelope fs-26 text-white" aria-hidden="true" />
                <a
                  href="mailto:info@solario.com"
                  className="link-body ms-2 text-white"
                  aria-label="Email Solario"
                >
                  info@solario.com
                </a>
              </div>

              <div className="d-flex align-items-center">
                <i className="uil uil-phone-volume fs-26 text-white" aria-hidden="true" />
                <a
                  href="tel:+919999999999"
                  className="ms-2 fs-18 text-white"
                  aria-label="Call Solario"
                >
                  +91 99999 99999
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Divider */}
        <hr className="mt-4 mb-3" />

        {/* Bottom Section */}
        <div className="d-md-flex align-items-center justify-content-center">
          <p className="mb-2 mb-lg-0 text-white text-center">
            © {currentYear} Solario. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
