import { useRef } from 'react';
import { useRouter } from 'next/router';
import useSticky from 'hooks/useSticky';
import NextLink from 'components/NextLink';
import SocialLinks from 'components/SocialLinks';
import ListItemLink from 'components/ListItemLink';
import DropdownToggleLink from 'components/DropdownToggleLink';
import { services } from '../data';

/**
 * Navbar Component
 *
 * Renders a responsive and sticky navigation bar with dropdowns and off-canvas mobile support.
 *
 * @component
 * @param {Object} props
 * @param {string} props.navClassName - Class for default navbar styling.
 * @param {string} props.navOtherClass - Class for mobile toggle button container.
 * @param {boolean} props.fancy - Flag to render fancy (wrapped) header layout.
 * @param {boolean} props.stickyBox - Flag to enable sticky padding to prevent layout shift.
 * @returns {JSX.Element}
 */
const Navbar = ({
  navClassName = 'navbar navbar-expand-lg center-nav transparent navbar-light',
  navOtherClass = 'navbar-other d-flex d-lg-none',
  fancy = false,
  stickyBox = true,
}) => {
  const sticky = useSticky(350);
  const navbarRef = useRef(null);
  const router = useRouter();

  const fixedClassName = 'navbar navbar-expand-lg center-nav transparent navbar-light navbar-clone fixed';

  /**
   * Handles routing to the Solar EPC Services page.
   */
  const handleSolarEPCServices = () => {
    router.push('#');
  };

  /**
   * Renders child dropdown links recursively.
   *
   * @param {Array} links - Array of link objects with title and url.
   * @returns {JSX.Element[]} List of dropdown link items.
   */
  const renderLinks = (links) => {
    return links.map((item) => (
      <ListItemLink
        key={item.id}
        href={item.url}
        title={item.title}
        linkClassName="dropdown-item"
      />
    ));
  };

  const headerContent = (
    <>
      {/* Logo */}
      <div className="navbar-brand w-100">
        <NextLink
          href="/"
          title="Solario"
          className="text-main display-4"
        />
      </div>

      {/* Offcanvas Navigation for Mobile */}
      <div
        id="offcanvas-nav"
        className="navbar-collapse offcanvas offcanvas-nav offcanvas-start"
        data-bs-scroll="true"
      >
        {/* Offcanvas Header */}
        <div className="offcanvas-header d-lg-none offcanvas-bg">
          <NextLink
            href="/"
            title="Solario"
            className="text-main display-4"
          />
          <button
            type="button"
            className="btn-close btn-close-white ms-auto"
            data-bs-dismiss="offcanvas"
            aria-label="Close"
          />
        </div>

        {/* Offcanvas Body */}
        <div className="offcanvas-body ms-lg-auto d-flex flex-column h-100">
          <ul className="navbar-nav align-items-lg-center">
            <li className="nav-item" data-bs-dismiss="offcanvas">
              <NextLink href="/" title="Home" className="nav-link" />
            </li>
            <li className="nav-item" data-bs-dismiss="offcanvas">
              <NextLink href="#" title="About Us" className="nav-link" />
            </li>
            <li className="nav-item dropdown">
              <DropdownToggleLink
                title="Solar EPC"
                onClick={handleSolarEPCServices}
                className="nav-link dropdown-toggle"
              />
              <ul className="dropdown-menu mt-lg-3" data-bs-dismiss="offcanvas">
                {services.map(({ id, url, title, children }) =>
                  !url && children ? (
                    <li className="dropdown dropdown-submenu" key={id}>
                      <DropdownToggleLink title={title} />
                      <ul className="dropdown-menu">
                        {renderLinks(children)}
                      </ul>
                    </li>
                  ) : (
                    <ListItemLink
                      key={id}
                      href={`#`}
                      title={title}
                      linkClassName="dropdown-item"
                    />
                  )
                )}
              </ul>
            </li>
            <li className="nav-item" data-bs-dismiss="offcanvas">
              <NextLink href="#" title="Project" className="nav-link" />
            </li>
            <li className="nav-item" data-bs-dismiss="offcanvas">
              <NextLink href="#" title="Blog" className="nav-link" />
            </li>
            <li className="nav-item" data-bs-dismiss="offcanvas">
              <NextLink href="#" title="Contact Us" className="nav-link" />
            </li>
          </ul>

          {/* Offcanvas Footer */}
          <div className="offcanvas-footer d-lg-none">
            <div>
              <NextLink
                href="mailto:info@solario.com"
                title="info@solario.com"
                className="link-inverse"
              />
              <br />
              <NextLink href="tel:+919999999999" title="+91 99999 99999" />
              <br />
              <SocialLinks />
            </div>
          </div>
        </div>
      </div>

      {/* Hamburger Menu for Mobile */}
      <div className={navOtherClass}>
        <button
          className="hamburger offcanvas-nav-btn"
          data-bs-toggle="offcanvas"
          data-bs-target="#offcanvas-nav"
          aria-label="Toggle navigation"
        >
          <span />
        </button>
      </div>
    </>
  );

  return (
    <>
      {/* Prevent layout shift when sticky navbar becomes fixed */}
      {stickyBox && (
        <div
          style={{
            paddingTop: sticky ? navbarRef.current?.clientHeight ?? 0 : 0,
          }}
        />
      )}

      {/* Main Navbar Element */}
      <nav
        ref={navbarRef}
        className={sticky ? fixedClassName : navClassName}
      >
        {fancy ? (
          <div className="container">
            <div className="navbar-collapse-wrapper bg-white d-flex flex-row flex-nowrap w-100 justify-content-between align-items-center">
              {headerContent}
            </div>
          </div>
        ) : (
          <div className="container flex-lg-row flex-nowrap align-items-center">
            {headerContent}
          </div>
        )}
      </nav>
    </>
  );
};

export default Navbar;
