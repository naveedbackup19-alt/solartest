import PropTypes from 'prop-types';
import Carousel from 'components/Carousel';

/**
 * Hero Component
 *
 * Displays a full-screen hero section with a carousel of promotional slides.
 *
 * @component
 * @param {Object} props
 * @param {string} props.img - (Unused) fallback background image.
 * @param {string} props.heading - (Unused) fallback heading text.
 * @param {string} props.description - (Unused) fallback description text.
 * @returns {JSX.Element}
 */
const Hero = () => {
  const slides = [
    {
      backgroundImage: '/img/slider.webp',
      title: 'Trusted Solar Panel Installation for Homes & Businesses',
      overlayClass: 'bg-overlay-400',
    },
    {
      backgroundImage: '/img/slider-2.webp',
      title: 'Power Your Future with Clean & Affordable Solar Energy',
      overlayClass: 'bg-overlay-200',
    },
  ];

  return (
    <section className="wrapper bg-dark" aria-label="Hero Section Carousel">
      <div className="swiper-container swiper-hero dots-over">
        <Carousel
          slidesPerView={1}
          autoplay={{ delay: 7000, disableOnInteraction: false }}
        >
          {slides.map(({ backgroundImage, title, overlayClass }, index) => (
            <div
              key={index}
              className={`swiper-slide bg-overlay ${overlayClass} bg-dark bg-image`}
              style={{ backgroundImage: `url("${backgroundImage}")` }}
              role="group"
              aria-roledescription="slide"
              aria-label={`Slide ${index + 1} of ${slides.length}`}
            >
              <div className="container h-100">
                <div className="row h-100">
                  <div className="col-md-10 offset-md-1 col-lg-7 offset-lg-0 col-xl-6 col-xxl-5 text-center text-lg-start d-flex justify-content-center align-items-start align-self-center">
                    <h1 className="display-1 fs-56 mb-4 text-white animate__animated animate__slideInDown animate__delay-1s">
                      {title}
                    </h1>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </Carousel>
      </div>
    </section>
  );
};

Hero.propTypes = {
  img: PropTypes.string,
  heading: PropTypes.string,
  description: PropTypes.string,
};

export default Hero;
