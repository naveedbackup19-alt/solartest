export const usefulLinks = [
  {
    id: 1,
    title: 'Home',
    url: '/'
  },
  {
    id: 2,
    title: 'About Us',
    url: '#'
  },
  {
    id: 3,
    title: 'Solar EPC',
    url: '#'
  },
  {
    id: 3,
    title: 'Projects',
    url: '#'
  },
  {
    id: 3,
    title: 'Blog',
    url: '#'
  },
  {
    id: 5,
    title: 'Contact Us',
    url: '#'
  },
  {
    id: 6,
    title: 'Privacy Policy',
    url: '#'
  }
];

export const services = [
  {
    id: 1,
    title: 'Commercial Solar',
    url: '#'
  },
  {
    id: 2,
    title: 'Ground Mounted Solar',
    url: '#'
  },
  {
    id: 3,
    title: 'Industrial Solar',
    url: '#'
  },
  {
    id: 3,
    title: 'Projects',
    url: '#'
  },
  {
    id: 3,
    title: 'Residential Solar',
    url: '#'
  },
  {
    id: 5,
    title: 'Roof Mounted Solar',
    url: '#'
  },
  {
    id: 6,
    title: 'Solar Finance',
    url: '#'
  },
  {
    id: 7,
    title: 'Solar Pump',
    url: '#'
  },
  {
    id: 8,
    title: 'Tracker Solar',
    url: '#'
  }
];
